void abinDEBUGcreate(char* fileloc)
{
    char bufferzin[4];
    FILE * fp;
    fp = fopen(fileloc, "w+");
    for(int i =0; i<512; i++)
    {
        fputs("debug", fp);
        
        snprintf(bufferzin, 4, "%d", i);
        fputs(bufferzin,fp);
        fputs(" vazio\n",fp);
    }
    fclose(fp);
}

void abinDEBUGtext(char* input)
{
    if(AbinGlobalIsDebug == false)
    {
        abinDEBUGcreate("./data/debug.text");
        AbinGlobalIsDebug = true;
    }
    char buff[35];
    for(int i =0; i<512; i++)
    {
        snprintf(buff,35,"debug%d",i);
        if(strcmp(abinCoreReturnData("./data/debug.text",buff),"vazio") == 0)
        {
            abinCoreEditData("data/debug.text",buff,input);
            i = 4544;
        }
    }
}

void abinDEBUGint(int input)
{
    char buff[35],traducao[30];
    snprintf(traducao,30,"%d",input);
    for(int i =0; i<10; i++)
    {
        snprintf(buff,35,"debug%d",i);
        if(strcmp(abinCoreReturnData("data/debug.text",buff),"vazio") == 0)
        {
            abinCoreEditData("data/debug.text",buff,traducao);
            i=98746546;
        }
    }
}

void abinDEBUGfloat(float input)
{
    char buff[35],traducao[30];
    snprintf(traducao,30,"%f",input);
    for(int i =0; i<20; i++)
    {
        snprintf(buff,35,"debug%d",i);
        if(strcmp(abinCoreReturnData("data/debug.text",buff),"vazio") == 0)
        {
            abinCoreEditData("data/debug.text",buff,traducao);
            i=8391273;
        }
    }
}
